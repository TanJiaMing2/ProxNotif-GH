<?php
header('Content-Type: application/json');

$servername = "www.dcs5604.com";
$username = "tanjm";
$password = "tanjm221";
$dbname = "proxnotif";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$title = $data['title'];
$description = $data['description'];
$categori = $data['categori'];
$address=$data['address'];

// Insert new entry
$sql = "INSERT INTO offers (title, description, categori,address) VALUES (?, ?, ?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $title, $description, $categori,$address);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Entry created successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Entry creation failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
