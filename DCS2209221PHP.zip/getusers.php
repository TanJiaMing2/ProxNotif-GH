<?php
$servername = "www.dcs5604.com";
$username = "tanjm";
$password = "tanjm221";
$dbname = "proxnotif";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch users
$sql = "SELECT UserID, Username, UserEmail FROM users";
$result = $conn->query($sql);

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row['UserID'] . ',' . $row['Username'] . ',' . $row['UserEmail'];
}

echo implode(';', $users);

$conn->close();
?>
