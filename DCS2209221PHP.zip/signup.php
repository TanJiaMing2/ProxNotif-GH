<?php
header('Content-Type: application/json');

$servername = "www.dcs5604.com";
$username = "tanjm";
$password = "tanjm221";
$dbname = "proxnotif";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'];
$email = $data['email'];
$password = $data['password'];

// Check if user exists
$sql = "SELECT * FROM users WHERE UserEmail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'User already exists']);
} else {
    // Insert new user
    $sql = "INSERT INTO users (Username,UserEmail, UserPw) VALUES (?,?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss",$username, $email, $password);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'User registered successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'User registration failed']);
    }
}

$stmt->close();
$conn->close();
?>
