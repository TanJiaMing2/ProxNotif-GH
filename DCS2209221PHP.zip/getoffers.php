<?php
$servername = "www.dcs5604.com";
$username = "tanjm";
$password = "tanjm221";
$dbname = "proxnotif";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch users
$sql = "SELECT listid, title, description, categori,address FROM offers";
$result = $conn->query($sql);

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row['listid'] . ',' . $row['title'] . ',' . $row['description'] . ',' . $row['categori']. ',' . $row['address'];
}

echo implode(';', $users);

$conn->close();
?>
