<?php
header('Content-Type: application/json');

$servername = "www.dcs5604.com";
$username = "tanjm";
$password = "tanjm221";
$dbname = "proxnotif";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'];
$password = $data['password'];

// Check if user exists
$sql = "SELECT * FROM users WHERE UserEmail = ? AND UserPw = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User authenticated, generate and return token
    $user = $result->fetch_assoc();
    $user_id = $user['UserID'];
    $token = generateToken($user_id); // Replace with your token generation logic
    echo json_encode(['success' => true, 'token' => $token]);
} else {
    // Invalid credentials
    echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
}

$stmt->close();
$conn->close();

// Token generation function (example, adjust as per your requirements)
function generateToken($user_id) {
    // Example: Generate a simple token based on user ID and current time
    return md5($user_id . microtime());
}
?>
